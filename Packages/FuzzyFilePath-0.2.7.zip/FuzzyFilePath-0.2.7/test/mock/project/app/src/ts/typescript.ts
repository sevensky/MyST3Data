import * from ./other.ts
import {test} from "../../../bower_components/angular"
from "./another.ts"
import "./typescript";

// <reference path="" />
