openfolder
==========

A SublimeText plugin to add a context menu option to open folders from the side bar.