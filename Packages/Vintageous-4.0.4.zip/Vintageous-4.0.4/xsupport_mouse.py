import sublime
import sublime_plugin

from Vintageous.vi.utils import IrreversibleMouseTextCommand
