***
# Youdao Translate [English/Chinese] - translate plugin for Sublime Text 2
***
====================

mail: [friskfly@gmail.com](mailto:friskfly@gmail.com)
weibo: [weibo.com/friskfly](http://weibo.com/friskfly)

##Summary
Auto translate Chinese to English or English to Chinese. 


##Usage


Use the right-click context menu command *Youdao Translate* or the keyboard shortcut *CTRL + Shift + T*  ( *COMMAND + Shift + T* on Mac OS X ).

	
## Installation
Using the Sublime Text 2 Package Control plugin (http://wbond.net/sublime_packages/package_control)
press *CTRL + SHIFT + P* and find **Package Control: Install Package** and press *Enter*.
Find this plugin in the list by name **Youdao Translate**.

Or git clone to your Sublime Text 2 packages folder directly (usually located at /Sublime Text 2/Packages/).
