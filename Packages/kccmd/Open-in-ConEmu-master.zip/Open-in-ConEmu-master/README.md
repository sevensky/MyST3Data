Open-in-ConEmu
==============

Sublime package.  Adds a context menu item to folders in the side bar to open the folder in a new ConEmu tab.