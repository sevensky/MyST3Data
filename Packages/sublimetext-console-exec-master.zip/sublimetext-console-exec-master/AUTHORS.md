Authors
=======

[Console Exec][home] is written and maintained by Joe Esposito ([@joeyespo][]),
along with the following contributors:

- Jack Cherng ([@jfcherng][])


[home]: README.md
[@joeyespo]: https://github.com/joeyespo
[@jfcherng]: https://github.com/jfcherng
