Console Exec Changelog
----------------------


### Version 5.0.0 (2015-06-02)

- Bugfix: Fix Linux support when `bash` is not the default shell ([#5](https://github.com/joeyespo/grip/pull/5) - thanks, [@jfcherng][]!)


### Version 4.0.0 (2015-05-30)

- Enhancement: Linux support
- Follow PEP8 standard


### Version 3.0.0 (2013-04-21)

- Enhancement: Remove launch.exe dependency
- Simplify code


### Version 1.0.0 (2012-11-18)

- First public release


[@jfcherng]: https://github.com/jfcherng
